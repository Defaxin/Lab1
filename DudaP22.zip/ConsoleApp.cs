﻿using System.Collections.Specialized;

namespace ConsoleApp1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\nTask 1: ");
            Work.Task1();
            Console.WriteLine("\nTask 2: ");
            Work.Task2();
            Console.WriteLine("\nTask 3: ");
            Work.Task3();
            Console.WriteLine("\nTask 4: ");
            Work.Task4();
            Console.WriteLine("\nTask 5: ");
            Work.Task5();
            Console.WriteLine("\nTask 6: ");
            Work.Task6();
        }
    }
}